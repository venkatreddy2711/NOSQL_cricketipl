dirname(getwd())
#C:\Users\91798\Downloads

setwd("C:\\Users\\91798\\Downloads")

data <- read.csv("Lab_Assignment_2.csv")

x <- data[,c(1:15)]
x

y <- data$stunting
y

reg <- lm(y~as.matrix(x))
reg

summary(reg)

SSR <- deviance(reg)
SSR

DegreesofFreedom <- reg$df
DegreesofFreedom

coef <- reg$coefficient
coef

resid <- reg$residuals
resid

aic <- AIC(reg)
aic

rsquare <- reg$r.square
rsquare

reg1 <- lm(y~as.matrix(x) -1)
reg1

summary(reg1)
